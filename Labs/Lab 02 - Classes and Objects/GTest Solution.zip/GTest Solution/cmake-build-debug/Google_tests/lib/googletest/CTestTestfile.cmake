# CMake generated Testfile for 
# Source directory: /Users/rwkramer/School/Courses/3700.course/Labs/02 - Classes and Objects/GTest Solution/Google_tests/lib/googletest
# Build directory: /Users/rwkramer/School/Courses/3700.course/Labs/02 - Classes and Objects/GTest Solution/cmake-build-debug/Google_tests/lib/googletest
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
