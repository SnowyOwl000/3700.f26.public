//
// Created by Dr. Bob Kramer on 8/25/26.
//

#include <numeric>

#include "gtest/gtest.h"
#include "../fraction.h"


TEST(FTestSuite, Constructor) {
    Fraction
         f1(42,-301),
         f2(5),
         f3;

    EXPECT_EQ(f1.getNum(),-6);
    EXPECT_EQ(f1.getDen(),43);
    EXPECT_EQ(f2.getNum(),5);
    EXPECT_EQ(f2.getDen(),1);
    EXPECT_EQ(f3.getNum(),0);
    EXPECT_EQ(f3.getDen(),1);
}

TEST(FTestSuite, Output) {
    Fraction
         f1(42,-301),
         f2(5),
         f3;
    std::stringstream
        sstr;

    sstr << f1;
    EXPECT_EQ(sstr.str(),"-6 / 43");
    sstr.str("");
    sstr << f2;
    EXPECT_EQ(sstr.str(),"5 / 1");
    sstr.str("");
    sstr << f3;
    EXPECT_EQ(sstr.str(),"0 / 1");
}

TEST(FTestSuite, Input) {
    Fraction
        f1;
    std::stringstream
        sstr;

    sstr.str("2/-4");
    sstr >> f1;
    EXPECT_EQ(f1.getNum(),-1);
    EXPECT_EQ(f1.getDen(),2);
}

TEST(FTestSuite, Add) {
    Fraction
        f1(7,6),
        f2(12,8),
        f3;

    f3 = f1 + f2;
    EXPECT_EQ(f3.getNum(),8);
    EXPECT_EQ(f3.getDen(),3);

    f3 = f1 + 2;
    EXPECT_EQ(f3.getNum(),19);
    EXPECT_EQ(f3.getDen(),6);
}

TEST(FTestSuite, Subtract) {
    Fraction
        f1(7,6),
        f2(12,8),
        f3;

    f3 = f1 - f2;
    EXPECT_EQ(f3.getNum(),-1);
    EXPECT_EQ(f3.getDen(),3);

    f3 = f1 - 2;
    EXPECT_EQ(f3.getNum(),-5);
    EXPECT_EQ(f3.getDen(),6);
}

TEST(FTestSuite, Multiply) {
    Fraction
        f1(7,6),
        f2(12,8),
        f3;

    f3 = f1 * f2;
    EXPECT_EQ(f3.getNum(),7);
    EXPECT_EQ(f3.getDen(),4);

    f3 = f1 * 2;
    EXPECT_EQ(f3.getNum(),7);
    EXPECT_EQ(f3.getDen(),3);
}

TEST(FTestSuite, Divide) {
    Fraction
        f1(7,6),
        f2(12,8),
        f3;

    f3 = f1 / f2;
    EXPECT_EQ(f3.getNum(),7);
    EXPECT_EQ(f3.getDen(),9);

    f3 = f1 / 2;
    EXPECT_EQ(f3.getNum(),7);
    EXPECT_EQ(f3.getDen(),12);
}

TEST(FTestSuite, Assign) {
    Fraction
        f1(7,6),
        f2(12,8);

    EXPECT_NE(f1.getNum(),f2.getNum());
    EXPECT_NE(f1.getDen(),f2.getDen());

    f2 = f1;
    EXPECT_EQ(f1.getNum(),f2.getNum());
    EXPECT_EQ(f1.getDen(),f2.getDen());
}

TEST(FTestSuite, Eq) {
    Fraction
        f1(7,6),
        f2(12,8);

    EXPECT_FALSE(f1 == f2);
    EXPECT_FALSE(f1 == 2);
    EXPECT_TRUE(f1 == f1);
}

TEST(FTestSuite, Ne) {
    Fraction
        f1(7,6),
        f2(12,8);

    EXPECT_TRUE(f1 != f2);
    EXPECT_TRUE(f1 != 2);
    EXPECT_FALSE(f1 != f1);
}

TEST(FTestSuite, Lt) {
    Fraction
        f1(7,6),
        f2(12,8);

    EXPECT_TRUE(f1 < f2);
    EXPECT_FALSE(f2 < f1);
    EXPECT_TRUE(f1 < 2);
    EXPECT_FALSE(f1 < f1);
}

TEST(FTestSuite, Gt) {
    Fraction
        f1(7,6),
        f2(12,8);

    EXPECT_FALSE(f1 > f2);
    EXPECT_TRUE(f2 > f1);
    EXPECT_FALSE(f1 > 2);
    EXPECT_FALSE(f1 > f1);
}

TEST(FTestSuite, Le) {
    Fraction
        f1(7,6),
        f2(12,8);

    EXPECT_TRUE(f1 <= f2);
    EXPECT_FALSE(f2 <= f1);
    EXPECT_TRUE(f1 <= 2);
    EXPECT_TRUE(f1 <= f1);
}

TEST(FTestSuite, Ge) {
    Fraction
        f1(7,6),
        f2(12,8);

    EXPECT_FALSE(f1 >= f2);
    EXPECT_TRUE(f2 >= f1);
    EXPECT_FALSE(f1 >= 2);
    EXPECT_TRUE(f1 >= f1);
}
