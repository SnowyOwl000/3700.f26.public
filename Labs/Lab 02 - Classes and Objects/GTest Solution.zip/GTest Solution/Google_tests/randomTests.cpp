//
// Created by Dr. Bob Kramer on 8/25/26.
//

#include <numeric>
#include <random>
#include <strstream>

#include "gtest/gtest.h"
#include "../fraction.h"

const uint32_t
    NUM_TESTS = 100000000;

TEST(RandomSuite, Add) {
    Fraction
        f3;
    int32_t
        nSum,dSum,
        n1,d1,n2,d2,
        g;
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<int32_t>
        nDis(-32767,32767),
        dDis(1,32767);

    for (uint32_t i=0;i<NUM_TESTS;i++) {
        n1 = nDis(mt);
        n2 = nDis(mt);
        d1 = dDis(mt);
        d2 = dDis(mt);
        Fraction
            f1(n1,d1),
            f2(n2,d2);

        f3 = f1 + f2;

        nSum = n1 * d2 + n2 * d1;
        dSum = d1 * d2;

        if (dSum < 0) {
            nSum = -nSum;
            dSum = -dSum;
        }

        g = std::gcd(nSum,dSum);
        nSum /= g;
        dSum /= g;

        EXPECT_EQ(f3.getNum(),nSum);
        EXPECT_EQ(f3.getDen(),dSum);
    }
}

TEST(RandomSuite, Subtract) {
    Fraction
        f3;
    int32_t
        nDiff,dDiff,
        n1,d1,n2,d2,
        g;
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<int32_t>
        nDis(-32767,32767),
        dDis(1,32767);

    for (uint32_t i=0;i<NUM_TESTS;i++) {
        n1 = nDis(mt);
        n2 = nDis(mt);
        d1 = dDis(mt);
        d2 = dDis(mt);
        Fraction
            f1(n1,d1),
            f2(n2,d2);

        f3 = f1 - f2;

        nDiff = n1 * d2 - n2 * d1;
        dDiff = d1 * d2;

        if (dDiff < 0) {
            nDiff = -nDiff;
            dDiff = -dDiff;
        }

        g = std::gcd(nDiff,dDiff);
        nDiff /= g;
        dDiff /= g;

        EXPECT_EQ(f3.getNum(),nDiff);
        EXPECT_EQ(f3.getDen(),dDiff);
    }
}

TEST(RandomSuite, Multiply) {
    Fraction
        f3;
    int32_t
        nProd,dProd,
        n1,d1,n2,d2,
        g;
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<int32_t>
        nDis(-32767,32767),
        dDis(1,32767);

    for (uint32_t i=0;i<NUM_TESTS;i++) {
        n1 = nDis(mt);
        n2 = nDis(mt);
        d1 = dDis(mt);
        d2 = dDis(mt);
        Fraction
            f1(n1,d1),
            f2(n2,d2);

        f3 = f1 * f2;

        nProd = n1 * n2;
        dProd = d1 * d2;

        if (dProd < 0) {
            nProd = -nProd;
            dProd = -dProd;
        }

        g = std::gcd(nProd,dProd);
        nProd /= g;
        dProd /= g;

        EXPECT_EQ(f3.getNum(),nProd);
        EXPECT_EQ(f3.getDen(),dProd);
    }
}

TEST(RandomSuite, Divide) {
    Fraction
        f3;
    int32_t
        nQuo,dQuo,
        n1,d1,n2,d2,
        g;
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<int32_t>
        nDis(-32767,32767),
        dDis(1,32767);

    for (uint32_t i=0;i<NUM_TESTS;i++) {
        n1 = nDis(mt);
        n2 = dDis(mt);
        d1 = dDis(mt);
        d2 = nDis(mt);
        Fraction
            f1(n1,d1),
            f2(n2,d2);

        f3 = f1 / f2;

        nQuo = n1 * d2;
        dQuo = d1 * n2;

        if (dQuo < 0) {
            nQuo = -nQuo;
            dQuo = -dQuo;
        }

        g = std::gcd(nQuo,dQuo);
        nQuo /= g;
        dQuo /= g;

        EXPECT_EQ(f3.getNum(),nQuo);
        EXPECT_EQ(f3.getDen(),dQuo);
    }
}

TEST(RandomSuite, Eq) {
    int32_t
        n1,d1,n2,d2;
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<int32_t>
        nDis(-32767,32767),
        dDis(1,32767);

    for (uint32_t i=0;i<NUM_TESTS;i++) {
        n1 = nDis(mt);
        n2 = nDis(mt);
        d1 = dDis(mt);
        d2 = dDis(mt);
        Fraction
            f1(n1,d1),
            f2(n2,d2);

        EXPECT_EQ(f1 == f2,
                    f1.getNum() * f2.getDen() ==
                        f1.getDen() * f2.getNum());
    }
}

TEST(RandomSuite, Ne) {
    int32_t
        n1,d1,n2,d2;
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<int32_t>
        nDis(-32767,32767),
        dDis(1,32767);

    for (uint32_t i=0;i<NUM_TESTS;i++) {
        n1 = nDis(mt);
        n2 = nDis(mt);
        d1 = dDis(mt);
        d2 = dDis(mt);
        Fraction
            f1(n1,d1),
            f2(n2,d2);

        EXPECT_EQ(f1 != f2,
                    f1.getNum() * f2.getDen() !=
                        f1.getDen() * f2.getNum());
    }
}

TEST(RandomSuite, Lt) {
    int32_t
        n1,d1,n2,d2;
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<int32_t>
        nDis(-32767,32767),
        dDis(1,32767);

    for (uint32_t i=0;i<NUM_TESTS;i++) {
        n1 = nDis(mt);
        n2 = nDis(mt);
        d1 = dDis(mt);
        d2 = dDis(mt);
        Fraction
            f1(n1,d1),
            f2(n2,d2);

        EXPECT_EQ(f1 < f2,
                    f1.getNum() * f2.getDen() <
                        f1.getDen() * f2.getNum());
    }
}

TEST(RandomSuite, Gt) {
    int32_t
        n1,d1,n2,d2;
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<int32_t>
        nDis(-32767,32767),
        dDis(1,32767);

    for (uint32_t i=0;i<NUM_TESTS;i++) {
        n1 = nDis(mt);
        n2 = nDis(mt);
        d1 = dDis(mt);
        d2 = dDis(mt);
        Fraction
            f1(n1,d1),
            f2(n2,d2);

        EXPECT_EQ(f1 > f2,
                    f1.getNum() * f2.getDen() >
                        f1.getDen() * f2.getNum());
    }
}

TEST(RandomSuite, Le) {
    int32_t
        n1,d1,n2,d2;
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<int32_t>
        nDis(-32767,32767),
        dDis(1,32767);

    for (uint32_t i=0;i<NUM_TESTS;i++) {
        n1 = nDis(mt);
        n2 = nDis(mt);
        d1 = dDis(mt);
        d2 = dDis(mt);
        Fraction
            f1(n1,d1),
            f2(n2,d2);

        EXPECT_EQ(f1 <= f2,
                    f1.getNum() * f2.getDen() <=
                        f1.getDen() * f2.getNum());
    }
}

TEST(RandomSuite, Ge) {
    int32_t
        n1,d1,n2,d2;
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<int32_t>
        nDis(-32767,32767),
        dDis(1,32767);

    for (uint32_t i=0;i<NUM_TESTS;i++) {
        n1 = nDis(mt);
        n2 = nDis(mt);
        d1 = dDis(mt);
        d2 = dDis(mt);
        Fraction
            f1(n1,d1),
            f2(n2,d2);

        EXPECT_EQ(f1 >= f2,
                    f1.getNum() * f2.getDen() >=
                        f1.getDen() * f2.getNum());
    }
}

TEST(RandomSuite, Assign) {
    int32_t
        n1,d1;
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<int32_t>
        nDis(-2147483648,2147483647),
        dDis(1,2147483647);

    for (uint32_t i=0;i<NUM_TESTS;i++) {
        n1 = nDis(mt);
        d1 = dDis(mt);
        Fraction
            f1(n1,d1),
            f2;

        f2 = f1;

        EXPECT_EQ(f1.getNum(),f2.getNum());
        EXPECT_EQ(f1.getDen(),f2.getDen());
    }
}

TEST(RandomSuite, Constructor2) {
    int32_t
        n1,d1;
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<int32_t>
        nDis(-2147483648,2147483647),
        dDis(1,2147483647);

    for (uint32_t i=0;i<NUM_TESTS;i++) {
        n1 = nDis(mt);
        d1 = dDis(mt);
        Fraction
            f1(n1,d1);
        int32_t
            g = std::gcd(n1,d1);

        n1 /= g;
        d1 /= g;

        EXPECT_EQ(f1.getNum(),n1);
        EXPECT_EQ(f1.getDen(),d1);
    }
}

TEST(RandomSuite, Constructor1) {
    int32_t
        n1;
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<int32_t>
        nDis(-2147483648,2147483647),
        dDis(1,2147483647);

    for (uint32_t i=0;i<NUM_TESTS;i++) {
        n1 = nDis(mt);
        Fraction
            f1(n1);

        EXPECT_EQ(f1.getNum(),n1);
        EXPECT_EQ(f1.getDen(),1);
    }
}

TEST(RandomSuite, Input) {
    int32_t
        n1,d1;
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<int32_t>
        nDis(-2147483648,2147483647),
        dDis(1,2147483647);

    for (uint32_t i=0;i<NUM_TESTS;i++) {
        n1 = nDis(mt);
        d1 = dDis(mt);
        Fraction
            f1;
        std::stringstream
            sstr;
        int32_t
            g = std::gcd(n1,d1);

        sstr << n1 << " / " << d1;
        sstr >> f1;

        n1 /= g;
        d1 /= g;

        EXPECT_EQ(f1.getNum(),n1);
        EXPECT_EQ(f1.getDen(),d1);
    }
}

TEST(RandomSuite, Output) {
    int32_t
        n1,d1;
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<int32_t>
        nDis(-2147483648,2147483647),
        dDis(1,2147483647);

    for (uint32_t i=0;i<NUM_TESTS;i++) {
        n1 = nDis(mt);
        d1 = dDis(mt);
        Fraction
            f1(n1,d1),
            f2;
        std::stringstream
            sstr;

        sstr << f1;
        sstr >> f2;

        EXPECT_TRUE(f1 == f2);
    }
}

