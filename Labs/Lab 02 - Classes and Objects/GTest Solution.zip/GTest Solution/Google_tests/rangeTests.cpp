//
// Created by Dr. Bob Kramer on 8/25/26.
//

#include <numeric>
#include <strstream>

#include "gtest/gtest.h"
#include "../fraction.h"


TEST(RangeSuite, Add) {
    Fraction
        f3;
    int32_t
        nSum,dSum,
        g;
    for (int32_t d1=-50;d1<=50;d1++) {
        if (d1 == 0)
            continue;
        for (int32_t d2=-50;d2<=50;d2++) {
            if (d2 == 0)
                continue;
            for (int32_t n1=-50;n1<=50;n1++) {
                Fraction
                    f1(n1,d1);
                for (int32_t n2=-50;n2<=50;n2++) {
                    Fraction
                        f2(n2,d2);

                    f3 = f1 + f2;

                    nSum = n1 * d2 + n2 * d1;
                    dSum = d1 * d2;

                    if (dSum < 0) {
                        nSum = -nSum;
                        dSum = -dSum;
                    }

                    g = std::gcd(nSum,dSum);
                    nSum /= g;
                    dSum /= g;

                    EXPECT_EQ(f3.getNum(),nSum);
                    EXPECT_EQ(f3.getDen(),dSum);
                }
            }
        }
    }
}

TEST(RangeSuite, Subtract) {
    Fraction
        f3;
    int32_t
        nDiff,dDiff,
        g;
    for (int32_t d1=-50;d1<=50;d1++) {
        if (d1 == 0)
            continue;
        for (int32_t d2=-50;d2<=50;d2++) {
            if (d2 == 0)
                continue;
            for (int32_t n1=-50;n1<=50;n1++) {
                Fraction
                    f1(n1,d1);
                for (int32_t n2=-50;n2<=50;n2++) {
                    Fraction
                        f2(n2,d2);

                    f3 = f1 - f2;

                    nDiff = n1 * d2 - n2 * d1;
                    dDiff = d1 * d2;

                    if (dDiff < 0) {
                        nDiff = -nDiff;
                        dDiff = -dDiff;
                    }

                    g = std::gcd(nDiff,dDiff);
                    nDiff /= g;
                    dDiff /= g;

                    EXPECT_EQ(f3.getNum(),nDiff);
                    EXPECT_EQ(f3.getDen(),dDiff);
                }
            }
        }
    }
}

TEST(RangeSuite, Multiply) {
    Fraction
        f3;
    int32_t
        nProd,dProd,
        g;
    for (int32_t d1=-50;d1<=50;d1++) {
        if (d1 == 0)
            continue;
        for (int32_t d2=-50;d2<=50;d2++) {
            if (d2 == 0)
                continue;
            for (int32_t n1=-50;n1<=50;n1++) {
                Fraction
                    f1(n1,d1);
                for (int32_t n2=-50;n2<=50;n2++) {
                    Fraction
                        f2(n2,d2);

                    f3 = f1 * f2;

                    nProd = n1 * n2;
                    dProd = d1 * d2;

                    if (dProd < 0) {
                        nProd = -nProd;
                        dProd = -dProd;
                    }

                    g = std::gcd(nProd,dProd);
                    nProd /= g;
                    dProd /= g;

                    EXPECT_EQ(f3.getNum(),nProd);
                    EXPECT_EQ(f3.getDen(),dProd);
                }
            }
        }
    }
}

TEST(RangeSuite, Divide) {
    Fraction
        f3;
    int32_t
        nQuo,dQuo,
        g;
    for (int32_t d1=-50;d1<=50;d1++) {
        if (d1 == 0)
            continue;
        for (int32_t d2=-50;d2<=50;d2++) {
            for (int32_t n1=-50;n1<=50;n1++) {
                Fraction
                    f1(n1,d1);
                for (int32_t n2=-50;n2<=50;n2++) {
                    if (n2 == 0)
                        continue;

                    Fraction
                        f2(n2,d2);

                    f3 = f1 / f2;

                    nQuo = n1 * d2;
                    dQuo = d1 * n2;

                    if (dQuo < 0) {
                        nQuo = -nQuo;
                        dQuo = -dQuo;
                    }

                    g = std::gcd(nQuo,dQuo);
                    nQuo /= g;
                    dQuo /= g;

                    EXPECT_EQ(f3.getNum(),nQuo);
                    EXPECT_EQ(f3.getDen(),dQuo);
                }
            }
        }
    }
}

TEST(RangeSuite, Eq) {
    for (int32_t d1=-50;d1<=50;d1++) {
        if (d1 == 0)
            continue;
        for (int32_t d2=-50;d2<=50;d2++) {
            if (d2 == 0)
                continue;
            for (int32_t n1=-50;n1<=50;n1++) {
                Fraction
                    f1(n1,d1);
                for (int32_t n2=-50;n2<=50;n2++) {
                    Fraction
                        f2(n2,d2);

                    EXPECT_EQ(f1 == f2,
                        f1.getNum() * f2.getDen() ==
                            f1.getDen() * f2.getNum());
                }
            }
        }
    }
}

TEST(RangeSuite, Ne) {
    for (int32_t d1=-50;d1<=50;d1++) {
        if (d1 == 0)
            continue;
        for (int32_t d2=-50;d2<=50;d2++) {
            if (d2 == 0)
                continue;
            for (int32_t n1=-50;n1<=50;n1++) {
                Fraction
                    f1(n1,d1);
                for (int32_t n2=-50;n2<=50;n2++) {
                    Fraction
                        f2(n2,d2);

                    EXPECT_EQ(f1 != f2,
                        f1.getNum() * f2.getDen() !=
                            f1.getDen() * f2.getNum());
                }
            }
        }
    }
}

TEST(RangeSuite, Lt) {
    for (int32_t d1=-50;d1<=50;d1++) {
        if (d1 == 0)
            continue;
        for (int32_t d2=-50;d2<=50;d2++) {
            if (d2 == 0)
                continue;
            for (int32_t n1=-50;n1<=50;n1++) {
                Fraction
                    f1(n1,d1);
                for (int32_t n2=-50;n2<=50;n2++) {
                    Fraction
                        f2(n2,d2);

                    EXPECT_EQ(f1 < f2,
                        f1.getNum() * f2.getDen() <
                            f1.getDen() * f2.getNum());
                }
            }
        }
    }
}

TEST(RangeSuite, Gt) {
    for (int32_t d1=-50;d1<=50;d1++) {
        if (d1 == 0)
            continue;
        for (int32_t d2=-50;d2<=50;d2++) {
            if (d2 == 0)
                continue;
            for (int32_t n1=-50;n1<=50;n1++) {
                Fraction
                    f1(n1,d1);
                for (int32_t n2=-50;n2<=50;n2++) {
                    Fraction
                        f2(n2,d2);

                    EXPECT_EQ(f1 > f2,
                        f1.getNum() * f2.getDen() >
                            f1.getDen() * f2.getNum());
                }
            }
        }
    }
}

TEST(RangeSuite, Le) {
    for (int32_t d1=-50;d1<=50;d1++) {
        if (d1 == 0)
            continue;
        for (int32_t d2=-50;d2<=50;d2++) {
            if (d2 == 0)
                continue;
            for (int32_t n1=-50;n1<=50;n1++) {
                Fraction
                    f1(n1,d1);
                for (int32_t n2=-50;n2<=50;n2++) {
                    Fraction
                        f2(n2,d2);

                    EXPECT_EQ(f1 <= f2,
                        f1.getNum() * f2.getDen() <=
                            f1.getDen() * f2.getNum());
                }
            }
        }
    }
}

TEST(RangeSuite, Ge) {
    for (int32_t d1=-50;d1<=50;d1++) {
        if (d1 == 0)
            continue;
        for (int32_t d2=-50;d2<=50;d2++) {
            if (d2 == 0)
                continue;
            for (int32_t n1=-50;n1<=50;n1++) {
                Fraction
                    f1(n1,d1);
                for (int32_t n2=-50;n2<=50;n2++) {
                    Fraction
                        f2(n2,d2);

                    EXPECT_EQ(f1 >= f2,
                        f1.getNum() * f2.getDen() >=
                            f1.getDen() * f2.getNum());
                }
            }
        }
    }
}

TEST(RangeSuite, Assign) {
    for (int32_t n1=-10000;n1<=10000;n1++) {
        for (int32_t d1=-10000;d1<=10000;d1++) {
            if (d1 == 0)
                continue;

            Fraction
                f1(n1,d1),
                f2;

            f2 = f1;

            EXPECT_EQ(f1.getNum(),f2.getNum());
            EXPECT_EQ(f1.getDen(),f2.getDen());
        }
    }
}

TEST(RangeSuite, Constructor2) {
    for (int32_t n1=-10000;n1<=10000;n1++) {
        for (int32_t d1=-10000;d1<=10000;d1++) {
            if (d1 == 0)
                continue;

            Fraction
                f1(n1,d1);
            int32_t
                n,d,
                g = std::gcd(n1,d1);

            n = n1 / g;
            d = d1 / g;

            if (d < 0) {
                n = -n;
                d = -d;
            }

            EXPECT_EQ(f1.getNum(),n);
            EXPECT_EQ(f1.getDen(),d);
        }
    }
}

TEST(RangeSuite, Constructor1) {
    for (int32_t n1=-100000000;n1<=100000000;n1++) {
        Fraction
            f1(n1);

        EXPECT_EQ(f1.getNum(),n1);
        EXPECT_EQ(f1.getDen(),1);
    }
}

TEST(RangeSuite, Input) {
    for (int32_t n1=-5000;n1<=5000;n1++) {
        for (int32_t d1=-5000;d1<=5000;d1++) {
            if (d1 == 0)
                continue;

            Fraction
                f1;
            std::stringstream
                sstr;
            int32_t
                n,d,
                g = std::gcd(n1,d1);

            n = n1 / g;
            d = d1 / g;

            if (d < 0) {
                n = -n;
                d = -d;
            }

            sstr << n1 << " / " << d1;
            sstr >> f1;

            EXPECT_EQ(f1.getNum(),n);
            EXPECT_EQ(f1.getDen(),d);
        }
    }
}

TEST(RangeSuite, Output) {
    for (int32_t n1=-5000;n1<=5000;n1++) {
        for (int32_t d1=-5000;d1<=5000;d1++) {
            if (d1 == 0)
                continue;

            Fraction
                f1(n1,d1),
                f2;

            std::stringstream
                sstr;

            sstr << f1;
            sstr >> f2;

            EXPECT_TRUE(f1 == f2);
        }
    }
}

