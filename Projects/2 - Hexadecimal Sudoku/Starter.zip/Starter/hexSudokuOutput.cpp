//
// Created by Dr. Bob Kramer on 9/15/26.
//

#include "hexSudokuOutput.h"

#include <iostream>
#include <thread>
#include <chrono>

void drawEmptyBoard() {
    std::cout << "\033[2J\033[H\033(0lqqqqwqqqqwqqqqwqqqqk\n"
        "x    x    x    x    x\n"
        "x    x    x    x    x\n"
        "x    x    x    x    x\n"
        "x    x    x    x    x\n"
        "tqqqqnqqqqnqqqqnqqqqu\n"
        "x    x    x    x    x\n"
        "x    x    x    x    x\n"
        "x    x    x    x    x\n"
        "x    x    x    x    x\n"
        "tqqqqnqqqqnqqqqnqqqqu\n"
        "x    x    x    x    x\n"
        "x    x    x    x    x\n"
        "x    x    x    x    x\n"
        "x    x    x    x    x\n"
        "tqqqqnqqqqnqqqqnqqqqu\n"
        "x    x    x    x    x\n"
        "x    x    x    x    x\n"
        "x    x    x    x    x\n"
        "x    x    x    x    x\n"
        "mqqqqvqqqqvqqqqvqqqqj\033(B"
    ;
    std::cout.flush();
}

void fillCell(uint32_t row, uint32_t col, uint32_t value, uint32_t msDelay) {
    uint32_t
        dispRow, dispCol;

    dispRow = 5 * (row / 4) + row % 4 + 2;
    dispCol = 5 * (col / 4) + col % 4 + 2;

    if (value < 10)
        std::cout << "\033[" << dispRow << ';' << dispCol << 'H' << value;
    else
        std::cout << "\033[" << dispRow << ';' << dispCol << 'H' << (char)(value - 10 + 'a');
    std::cout.flush();
    std::this_thread::sleep_for(std::chrono::milliseconds(msDelay));
}

void clearCell(uint32_t row, uint32_t col, uint32_t msDelay) {
    uint32_t
        dispRow, dispCol;

    dispRow = 5 * (row / 4) + row % 4 + 2;
    dispCol = 5 * (col / 4) + col % 4 + 2;

    std::cout << "\033[" << dispRow << ';' << dispCol << "H\033[7m ";
    std::cout.flush();
    std::this_thread::sleep_for(std::chrono::milliseconds(msDelay));

    std::cout << "\033[" << dispRow << ';' << dispCol << "H\033[0m ";
    std::cout.flush();
    std::this_thread::sleep_for(std::chrono::milliseconds(msDelay));
}

void showStatus(const char *msg) {

    std::cout << "\033[1;30HStatus:        ";
    std::cout.flush();
    std::cout << "\033[1;38H" << msg;
    std::cout.flush();
    std::cout << "\033[22;1H";
    std::cout.flush();
}

void showError(const char *msg) {

    std::cout << "\033[3;30H\033[37;101mStatus: " << msg;
    std::cout.flush();
    std::cout << "\033[22;1H\033[0m";
    std::cout.flush();
}
