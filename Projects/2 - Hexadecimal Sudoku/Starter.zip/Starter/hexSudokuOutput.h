//
// Created by Dr. Bob Kramer on 9/15/26.
//

#ifndef HEXSUDOKUOUTPUT_H
#define HEXSUDOKUOUTPUT_H
#include <cstdint>

const uint32_t
    FILL_DELAY = 1,
    CLEAR_DELAY = 1;

void drawEmptyBoard();
void fillCell(uint32_t row, uint32_t col, uint32_t value, uint32_t msDelay);
void clearCell(uint32_t row, uint32_t col, uint32_t msDelay);
void showStatus(const char *msg);
void showError(const char *msg);

#endif //HEXSUDOKUOUTPUT_H
