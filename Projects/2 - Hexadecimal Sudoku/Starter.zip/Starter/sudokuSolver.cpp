//
// Created by Dr. Bob Kramer on 9/15/26.
//

#include "sudokuSolver.h"
#include <stack.h>
#include "hexSudokuOutput.h"

bool findBest(uint32_t board[][16],uint32_t &iBest, uint32_t &jBest) {

}

void solve(uint32_t board[][16]) {

}