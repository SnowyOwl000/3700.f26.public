//
// Created by Dr. Bob Kramer on 9/15/26.
//

#ifndef SUDOKUSOLVER_H
#define SUDOKUSOLVER_H

#include <cstdint>

const uint32_t
    IS_FILLED_IN = 0x80000000,
    IS_0_VALID   = 0x00000010,
    VALID_MASK   = 0x000ffff0,
    VALUE_MASK   = 0x0000000f;

void solve(uint32_t board[][16]);

#endif //SUDOKUSOLVER_H
