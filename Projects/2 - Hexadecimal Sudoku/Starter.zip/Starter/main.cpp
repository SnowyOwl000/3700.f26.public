#include <iostream>
#include "sudokuSolver.h"
#include "hexSudokuOutput.h"

int main() {
    uint32_t
        board[16][16];
    char
        ch;

    drawEmptyBoard();

    showStatus("Input");
    std::cout << "\033[92m";
    std::cout.flush();

    // read board here
    
    std::cout << "\033[0m";
    std::cout.flush();
    showStatus("Solving");

    solve(board);

    showStatus("Done");

    return 0;
}
